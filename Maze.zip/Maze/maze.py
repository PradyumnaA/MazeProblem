import sys
#Math module for eucledian distance caluclation
import math 
#Priority queue
from queue import PriorityQueue
#From python image library import image and image draw libraries

from PIL import Image,ImageDraw

class Node():
    def __init__(self, state, parent, action, goal, cost):
        self.state = state#state definition
        self.parent = parent#parent node the current state
        self.action = action#action move forward or backward
        self.goal = goal#goal state
        self.cost = cost#cost(Applicable only in Astar algorithm)
    def distance_calculate_euclidean(self, goal): #Euclidean distance method https://www.geeksforgeeks.org/python-math-dist-method/
        distance = math.dist(self.state, goal)#distance betweeen 2 points is measured
        return distance
    #Total cost = f(x)+g(x) that is heurestic function + the distance
    def total_cost(self):
        return self.cost + self.distance_calculate_euclidean(self.goal)
    def __lt__(self, other):
            #return the total cost which is lesser
        return self.total_cost() < other.total_cost()
    
class DFSStackFrontier():
    def __init__(self):
        self.frontier = []

    def add(self, node):
        self.frontier.append(node)

    def contains_state(self, state):
        return any(node.state == state for node in self.frontier)

    def empty(self):
        return len(self.frontier) == 0

    def remove(self):
        if self.empty():
            raise Exception("empty frontier")
        else:
            node = self.frontier[-1]
            self.frontier = self.frontier[:-1]
            return node

#Inheriting the DFSStack Frontier
class BFSQueueFrontier(DFSStackFrontier):
    def remove(self):
        if self.empty():
            raise Exception("empty frontier")
        else:
            node = self.frontier[0]
            self.frontier = self.frontier[1:]
            return node

#Defining the greedy frontier class
class GreedyFrontier(BFSQueueFrontier):
    def __init__(self):#initializing the priority queue source https://builtin.com/data-science/priority-queues-in-python
        self.frontier = PriorityQueue()

    def add(self, node):
        priority = node.distance_calculate_euclidean(node.goal)#After caluclating the distance add it to priority queue
        self.frontier.put((priority, node))# in list we have append or concat in priority queue it is put

    def contains_state(self, state):#Check if the state is present if so return it
        return any(item[1].state == state for item in list(self.frontier.queue))

    def empty(self):#Return the empty queue
        return self.frontier.empty()

    def remove(self):
        if self.empty():#Check if the queue is empty if so throw an exception to user stating that it is empty

            raise Exception("empty frontier")
        else:
            priority, node = self.frontier.get()
            return node

class AstarFrontier(GreedyFrontier):#Astar frontier algorithm inherits the greedy frontier but has different implementation

    def __init__(self):
        self.frontier=PriorityQueue()

    def add(self,node):
        priority=node.total_cost()
        self.frontier.put((priority,node))
    
    def contains_state(self, state):
        return any(item[1].state==state for item in list(self.frontier.queue))
  
   #Some of the methods are present in Greedy Frontier so need not mention here  as I am using inheritence here 
   


class Maze():#Maze implementation
    def __init__(self, filename):
        with open(filename) as f:
            contents = f.read()

        if contents.count("A") != 1:
            raise Exception("maze must have exactly one start point")
        if contents.count("B") != 1:
            raise Exception("maze must have exactly one goal")

        contents = contents.splitlines()
        self.height = len(contents)
        self.width = max(len(line) for line in contents)

        self.walls = []
        for i in range(self.height):
            row = []
            for j in range(self.width):
                try:
                    if contents[i][j] == "A":
                        self.start = (i, j)
                        row.append(False)
                    elif contents[i][j] == "B":
                        self.goal = (i, j)
                        row.append(False)
                    elif contents[i][j] == " ":
                        row.append(False)
                    else:
                        row.append(True)
                except IndexError:
                    row.append(False)
            self.walls.append(row)

        self.solution = None

    def print(self):
        solution = self.solution[1] if self.solution is not None else None
        print()
        for i, row in enumerate(self.walls):
            for j, col in enumerate(row):
                if col:
                    print("█", end="")
                elif (i, j) == self.start:
                    print("A", end="")
                elif (i, j) == self.goal:
                    print("B", end="")
                elif solution is not None and (i, j) in solution:
                    print("*", end="")
                else:
                    print(" ", end="")
            print()
        print()

    def neighbors(self, state):
        row, col = state
        candidates = [
            ("up", (row - 1, col)),
            ("down", (row + 1, col)),
            ("left", (row, col - 1)),
            ("right", (row, col + 1))
        ]

        result = []
        for action, (r, c) in candidates:
            if 0 <= r < self.height and 0 <= c < self.width and not self.walls[r][c]:
                result.append((action, (r, c)))
        return result

    def solve(self):
        self.num_explored = 0
        start = Node(state=self.start, parent=None, action=None, goal=self.goal, cost=0)#Cost is defined here
        frontier = AstarFrontier()
        # frontier = GreedyFrontier()
        frontier.add(start)
        self.explored = set()

        while True:
            if frontier.empty():
                raise Exception("no solution")

            node = frontier.remove()
            self.num_explored += 1

            if node.state == self.goal:
                actions = []
                cells = []
                while node.parent is not None:
                    actions.append(node.action)
                    cells.append(node.state)
                    node = node.parent
                actions.reverse()
                cells.reverse()
                self.solution = (actions, cells)
                return

            self.explored.add(node.state)

            for action, state in self.neighbors(node.state):
                if not frontier.contains_state(state) and state not in self.explored:
                    child_cost = node.cost + 1
                    child = Node(state=state, parent=node, action=action, goal=self.goal, cost=child_cost)
                    frontier.add(child)

    def output_image(self, filename, show_solution=True, show_explored=False):
        cell_size = 50
        cell_border = 2

        img = Image.new(
            "RGBA",
            (self.width * cell_size, self.height * cell_size),
            "black"
        )
        draw = ImageDraw.Draw(img)

        solution = self.solution[1] if self.solution is not None else None
        for i, row in enumerate(self.walls):
            for j, col in enumerate(row):

                if col:
                    fill = (40, 40, 40)
                elif (i, j) == self.start:
                    fill = (255, 0, 0)
                elif (i, j) == self.goal:
                    fill = (0, 171, 28)
                elif solution is not None and show_solution and (i, j) in solution:
                    fill = (220, 235, 113)
                elif solution is not None and show_explored and (i, j) in self.explored:
                    fill = (212, 97, 85)
                else:
                    fill = (237, 240, 252)

                draw.rectangle(
                    ([(j * cell_size + cell_border, i * cell_size + cell_border),
                      ((j + 1) * cell_size - cell_border, (i + 1) * cell_size - cell_border)]),
                    fill=fill
                )

        img.save(filename)

if len(sys.argv) != 2:
    sys.exit("Usage python maze.py maze.txt")

m = Maze(sys.argv[1])
print("Maze:")
m.print()
print("Solving...")
m.solve()
print("States:", m.num_explored)
print("Solution:")
m.print()
m.output_image("maze.png", show_explored=True)
